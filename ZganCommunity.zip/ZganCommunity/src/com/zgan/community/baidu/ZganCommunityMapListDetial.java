package com.zgan.community.baidu;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.zgan.community.R;
import com.zgan.community.tools.MainAcitivity;

public class ZganCommunityMapListDetial extends MainAcitivity {
	Button back;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.line_maplistdetails);
		back = (Button) findViewById(R.id.back);
		back.setOnClickListener(listener);
	}

	OnClickListener listener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			finish();
		}
	};
}
