package com.zgan.community.data;

public class Pay {
   private String ZDName;
   private String ZDStatus;
   private String ZDMoney;
public String getZDName() {
	return ZDName;
}
public void setZDName(String zDName) {
	ZDName = zDName;
}
public String getZDStatus() {
	return ZDStatus;
}
public void setZDStatus(String zDStatus) {
	ZDStatus = zDStatus;
}
public String getZDMoney() {
	return ZDMoney;
}
public void setZDMoney(String zDMoney) {
	ZDMoney = zDMoney;
}
}
