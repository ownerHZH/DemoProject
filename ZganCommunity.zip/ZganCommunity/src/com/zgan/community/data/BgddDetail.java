package com.zgan.community.data;

public class BgddDetail {
     private String name;
     private String tel;
     private String addr;
     private String addlx;
     private String gps;
     
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public String getAddlx() {
		return addlx;
	}
	public void setAddlx(String addlx) {
		this.addlx = addlx;
	}
	public String getGps() {
		return gps;
	}
	public void setGps(String gps) {
		this.gps = gps;
	}
}
