package com.zgan.community.data;

import java.util.Date;

/**
 * ��������ʵ����
 * @author Hzh
 *
 */
public class CommunityService {

	private int id;               //����ID
	private String name;          //����
	private String address;       //��ַ
	private String telephone;     //�绰
	private Date publishTime;     //����ʱ��
	private String publisher;     //������
	private int communityId;      //����ID
	private String gpsCoordinates;//�ٶȵ�ַ
	
	public CommunityService(String name, String address, String telephone) {
		this.name = name;
		this.address = address;
		this.telephone = telephone;
	}
	
	public CommunityService(){}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public Date getPublishTime() {
		return publishTime;
	}
	public void setPublishTime(Date publishTime) {
		this.publishTime = publishTime;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	public int getCommunityId() {
		return communityId;
	}
	public void setCommunityId(int communityId) {
		this.communityId = communityId;
	}
	public String getGpsCoordinates() {
		return gpsCoordinates;
	}
	public void setGpsCoordinates(String gpsCoordinates) {
		this.gpsCoordinates = gpsCoordinates;
	}

}
