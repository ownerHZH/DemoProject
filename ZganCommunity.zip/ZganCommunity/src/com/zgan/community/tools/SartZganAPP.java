package com.zgan.community.tools;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.util.Log;

public class SartZganAPP {
	

}
