package com.zgan.community.tools;

public class MapShow {
	String s_name;

	public String getS_name() {
		return s_name;
	}

	public void setS_name(String s_name) {
		this.s_name = s_name;
	}

	public String getS_address() {
		return s_address;
	}

	public void setS_address(String s_address) {
		this.s_address = s_address;
	}

	public String getS_tel() {
		return s_tel;
	}

	public void setS_tel(String s_tel) {
		this.s_tel = s_tel;
	}

	public String getS_lot() {
		return s_lot;
	}

	public void setS_lot(String s_lot) {
		this.s_lot = s_lot;
	}

	public String getS_lat() {
		return s_lat;
	}

	public void setS_lat(String s_lat) {
		this.s_lat = s_lat;
	}

	public String getS_poi() {
		return s_poi;
	}

	public void setS_poi(String s_poi) {
		this.s_poi = s_poi;
	}

	String s_address;
	String s_tel;
	String s_lot;
	String s_lat;
	String s_poi;

}
