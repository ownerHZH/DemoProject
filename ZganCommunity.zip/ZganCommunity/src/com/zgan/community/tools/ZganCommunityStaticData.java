package com.zgan.community.tools;

public class ZganCommunityStaticData {
	public static String User_Number;
	public static String User_PassWord;

}
