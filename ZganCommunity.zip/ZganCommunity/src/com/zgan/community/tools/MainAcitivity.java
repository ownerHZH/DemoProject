package com.zgan.community.tools;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.view.Window;

public class MainAcitivity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);

	}
}
