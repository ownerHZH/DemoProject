package com.zgan.community.jsontool;

import android.content.Context;

public interface HttpPreExecuteHandler {
	public void onPreExecute(Context context);
}
