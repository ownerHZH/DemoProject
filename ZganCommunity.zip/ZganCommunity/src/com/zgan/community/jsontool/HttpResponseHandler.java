package com.zgan.community.jsontool;


public interface HttpResponseHandler {
	public void onResponse(Object obj);
	//public void onResponseArray(JSONArray obj);
}
