/** Automatically generated file. DO NOT MODIFY */
package com.zgan.community;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}